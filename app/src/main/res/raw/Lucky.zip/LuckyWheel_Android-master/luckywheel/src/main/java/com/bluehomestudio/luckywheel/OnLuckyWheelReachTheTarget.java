package com.bluehomestudio.luckywheel;

/**
 * Created by mohamed on 24/04/17.
 */

public interface OnLuckyWheelReachTheTarget {
    void onReachTarget();
}
