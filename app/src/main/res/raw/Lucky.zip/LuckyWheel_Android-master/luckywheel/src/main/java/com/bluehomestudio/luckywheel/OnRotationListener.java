package com.bluehomestudio.luckywheel;

interface OnRotationListener {
    void onFinishRotation();
}
